﻿namespace OnlineQuiz
{
    partial class Question
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Question));
            this.qnonlabel = new System.Windows.Forms.Label();
            this.tqnlabel = new System.Windows.Forms.Label();
            this.qnolabel = new System.Windows.Forms.Label();
            this.tqlabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxChange = new System.Windows.Forms.ComboBox();
            this.ttlabel = new System.Windows.Forms.Label();
            this.txttimer = new System.Windows.Forms.TextBox();
            this.tlabel = new System.Windows.Forms.Label();
            this.button1 = new Guna.UI2.WinForms.Guna2Button();
            this.btnexit = new Guna.UI2.WinForms.Guna2Button();
            this.label2 = new System.Windows.Forms.Label();
            this.questionlabel = new System.Windows.Forms.Label();
            this.option1 = new System.Windows.Forms.RadioButton();
            this.option2 = new System.Windows.Forms.RadioButton();
            this.option3 = new System.Windows.Forms.RadioButton();
            this.option4 = new System.Windows.Forms.RadioButton();
            this.btnnext = new Guna.UI2.WinForms.Guna2Button();
            this.btnsubmit = new Guna.UI2.WinForms.Guna2Button();
            this.SuspendLayout();
            // 
            // qnonlabel
            // 
            this.qnonlabel.AutoSize = true;
            this.qnonlabel.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qnonlabel.ForeColor = System.Drawing.Color.Black;
            this.qnonlabel.Location = new System.Drawing.Point(213, 156);
            this.qnonlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.qnonlabel.Name = "qnonlabel";
            this.qnonlabel.Size = new System.Drawing.Size(19, 24);
            this.qnonlabel.TabIndex = 11;
            this.qnonlabel.Text = "1";
            // 
            // tqnlabel
            // 
            this.tqnlabel.AutoSize = true;
            this.tqnlabel.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tqnlabel.ForeColor = System.Drawing.Color.Black;
            this.tqnlabel.Location = new System.Drawing.Point(213, 118);
            this.tqnlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tqnlabel.Name = "tqnlabel";
            this.tqnlabel.Size = new System.Drawing.Size(31, 24);
            this.tqnlabel.TabIndex = 10;
            this.tqnlabel.Text = "10";
            // 
            // qnolabel
            // 
            this.qnolabel.AutoSize = true;
            this.qnolabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.qnolabel.ForeColor = System.Drawing.Color.Black;
            this.qnolabel.Location = new System.Drawing.Point(7, 155);
            this.qnolabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.qnolabel.Name = "qnolabel";
            this.qnolabel.Size = new System.Drawing.Size(179, 24);
            this.qnolabel.TabIndex = 9;
            this.qnolabel.Text = "Questions No     :";
            // 
            // tqlabel
            // 
            this.tqlabel.AutoSize = true;
            this.tqlabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tqlabel.ForeColor = System.Drawing.Color.Black;
            this.tqlabel.Location = new System.Drawing.Point(7, 117);
            this.tqlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tqlabel.Name = "tqlabel";
            this.tqlabel.Size = new System.Drawing.Size(178, 24);
            this.tqlabel.TabIndex = 8;
            this.tqlabel.Text = "Total Questions :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(7, 76);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 24);
            this.label1.TabIndex = 43;
            this.label1.Text = "Shift :";
            // 
            // comboBoxChange
            // 
            this.comboBoxChange.BackColor = System.Drawing.Color.White;
            this.comboBoxChange.FormattingEnabled = true;
            this.comboBoxChange.Location = new System.Drawing.Point(85, 76);
            this.comboBoxChange.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.comboBoxChange.Name = "comboBoxChange";
            this.comboBoxChange.Size = new System.Drawing.Size(159, 24);
            this.comboBoxChange.TabIndex = 42;
            this.comboBoxChange.SelectedIndexChanged += new System.EventHandler(this.comboBoxChange_SelectedIndexChanged);
            // 
            // ttlabel
            // 
            this.ttlabel.AutoSize = true;
            this.ttlabel.BackColor = System.Drawing.Color.Transparent;
            this.ttlabel.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ttlabel.ForeColor = System.Drawing.Color.White;
            this.ttlabel.Location = new System.Drawing.Point(1287, 106);
            this.ttlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.ttlabel.Name = "ttlabel";
            this.ttlabel.Size = new System.Drawing.Size(72, 24);
            this.ttlabel.TabIndex = 41;
            this.ttlabel.Text = "10 min";
            // 
            // txttimer
            // 
            this.txttimer.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttimer.Location = new System.Drawing.Point(1201, 134);
            this.txttimer.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txttimer.Name = "txttimer";
            this.txttimer.Size = new System.Drawing.Size(141, 26);
            this.txttimer.TabIndex = 40;
            this.txttimer.Text = "00:00:00";
            this.txttimer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tlabel
            // 
            this.tlabel.AutoSize = true;
            this.tlabel.BackColor = System.Drawing.Color.Transparent;
            this.tlabel.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tlabel.ForeColor = System.Drawing.Color.White;
            this.tlabel.Location = new System.Drawing.Point(1159, 106);
            this.tlabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.tlabel.Name = "tlabel";
            this.tlabel.Size = new System.Drawing.Size(120, 24);
            this.tlabel.TabIndex = 39;
            this.tlabel.Text = "Total Time :";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Transparent;
            this.button1.BorderRadius = 25;
            this.button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.button1.FillColor = System.Drawing.Color.LightGray;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageSize = new System.Drawing.Size(30, 30);
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(68, 46);
            this.button1.TabIndex = 44;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.BorderRadius = 25;
            this.btnexit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnexit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnexit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnexit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnexit.FillColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnexit.ForeColor = System.Drawing.Color.White;
            this.btnexit.Image = ((System.Drawing.Image)(resources.GetObject("btnexit.Image")));
            this.btnexit.ImageSize = new System.Drawing.Size(40, 40);
            this.btnexit.Location = new System.Drawing.Point(1285, 12);
            this.btnexit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(68, 46);
            this.btnexit.TabIndex = 45;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(632, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(157, 49);
            this.label2.TabIndex = 46;
            this.label2.Text = "QUIZ :";
            // 
            // questionlabel
            // 
            this.questionlabel.AutoSize = true;
            this.questionlabel.BackColor = System.Drawing.Color.Transparent;
            this.questionlabel.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.questionlabel.ForeColor = System.Drawing.Color.White;
            this.questionlabel.Location = new System.Drawing.Point(360, 174);
            this.questionlabel.Name = "questionlabel";
            this.questionlabel.Size = new System.Drawing.Size(600, 144);
            this.questionlabel.TabIndex = 47;
            this.questionlabel.Text = "Total Question :                                         \r\n                      " +
    "                                           \r\n                                   " +
    "                              \r\n\r\n";
            // 
            // option1
            // 
            this.option1.AutoSize = true;
            this.option1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("option1.BackgroundImage")));
            this.option1.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Italic);
            this.option1.ForeColor = System.Drawing.Color.White;
            this.option1.Location = new System.Drawing.Point(131, 443);
            this.option1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.option1.Name = "option1";
            this.option1.Size = new System.Drawing.Size(144, 27);
            this.option1.TabIndex = 48;
            this.option1.TabStop = true;
            this.option1.Text = "radioButton1";
            this.option1.UseVisualStyleBackColor = true;
            this.option1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // option2
            // 
            this.option2.AutoSize = true;
            this.option2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("option2.BackgroundImage")));
            this.option2.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Italic);
            this.option2.ForeColor = System.Drawing.Color.White;
            this.option2.Location = new System.Drawing.Point(725, 443);
            this.option2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.option2.Name = "option2";
            this.option2.Size = new System.Drawing.Size(147, 27);
            this.option2.TabIndex = 49;
            this.option2.TabStop = true;
            this.option2.Text = "radioButton2";
            this.option2.UseVisualStyleBackColor = true;
            this.option2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // option3
            // 
            this.option3.AutoSize = true;
            this.option3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("option3.BackgroundImage")));
            this.option3.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Italic);
            this.option3.ForeColor = System.Drawing.Color.White;
            this.option3.Location = new System.Drawing.Point(131, 577);
            this.option3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.option3.Name = "option3";
            this.option3.Size = new System.Drawing.Size(146, 27);
            this.option3.TabIndex = 51;
            this.option3.TabStop = true;
            this.option3.Text = "radioButton3";
            this.option3.UseVisualStyleBackColor = true;
            this.option3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // option4
            // 
            this.option4.AutoSize = true;
            this.option4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("option4.BackgroundImage")));
            this.option4.Font = new System.Drawing.Font("Georgia", 11.25F, System.Drawing.FontStyle.Italic);
            this.option4.ForeColor = System.Drawing.Color.White;
            this.option4.Location = new System.Drawing.Point(725, 577);
            this.option4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.option4.Name = "option4";
            this.option4.Size = new System.Drawing.Size(147, 27);
            this.option4.TabIndex = 52;
            this.option4.TabStop = true;
            this.option4.Text = "radioButton4";
            this.option4.UseVisualStyleBackColor = true;
            this.option4.CheckedChanged += new System.EventHandler(this.radioButton4_CheckedChanged);
            // 
            // btnnext
            // 
            this.btnnext.BackColor = System.Drawing.Color.Transparent;
            this.btnnext.BorderRadius = 25;
            this.btnnext.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnnext.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnnext.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnnext.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnnext.FillColor = System.Drawing.Color.Lime;
            this.btnnext.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnext.ForeColor = System.Drawing.Color.Black;
            this.btnnext.HoverState.FillColor = System.Drawing.Color.White;
            this.btnnext.HoverState.ForeColor = System.Drawing.Color.Black;
            this.btnnext.Image = ((System.Drawing.Image)(resources.GetObject("btnnext.Image")));
            this.btnnext.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btnnext.ImageSize = new System.Drawing.Size(25, 25);
            this.btnnext.Location = new System.Drawing.Point(1173, 729);
            this.btnnext.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnnext.Name = "btnnext";
            this.btnnext.Size = new System.Drawing.Size(180, 46);
            this.btnnext.TabIndex = 53;
            this.btnnext.Text = "NEXT";
            this.btnnext.Click += new System.EventHandler(this.btnnext_Click);
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.Transparent;
            this.btnsubmit.BorderRadius = 25;
            this.btnsubmit.DisabledState.BorderColor = System.Drawing.Color.DarkGray;
            this.btnsubmit.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray;
            this.btnsubmit.DisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(169)))), ((int)(((byte)(169)))), ((int)(((byte)(169)))));
            this.btnsubmit.DisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(141)))), ((int)(((byte)(141)))), ((int)(((byte)(141)))));
            this.btnsubmit.FillColor = System.Drawing.Color.Red;
            this.btnsubmit.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold);
            this.btnsubmit.ForeColor = System.Drawing.Color.Black;
            this.btnsubmit.HoverState.FillColor = System.Drawing.Color.White;
            this.btnsubmit.HoverState.ForeColor = System.Drawing.Color.Black;
            this.btnsubmit.Image = ((System.Drawing.Image)(resources.GetObject("btnsubmit.Image")));
            this.btnsubmit.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.btnsubmit.ImageSize = new System.Drawing.Size(50, 50);
            this.btnsubmit.Location = new System.Drawing.Point(12, 729);
            this.btnsubmit.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(180, 46);
            this.btnsubmit.TabIndex = 54;
            this.btnsubmit.Text = "SUBMIT    ";
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // Question
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1365, 785);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.option4);
            this.Controls.Add(this.option3);
            this.Controls.Add(this.option2);
            this.Controls.Add(this.option1);
            this.Controls.Add(this.questionlabel);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBoxChange);
            this.Controls.Add(this.ttlabel);
            this.Controls.Add(this.txttimer);
            this.Controls.Add(this.tlabel);
            this.Controls.Add(this.qnonlabel);
            this.Controls.Add(this.tqnlabel);
            this.Controls.Add(this.qnolabel);
            this.Controls.Add(this.tqlabel);
            this.ForeColor = System.Drawing.Color.White;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Question";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Question";
            this.Load += new System.EventHandler(this.Question_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label qnonlabel;
        private System.Windows.Forms.Label tqnlabel;
        private System.Windows.Forms.Label qnolabel;
        private System.Windows.Forms.Label tqlabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxChange;
        private System.Windows.Forms.Label ttlabel;
        private System.Windows.Forms.TextBox txttimer;
        private System.Windows.Forms.Label tlabel;
        private Guna.UI2.WinForms.Guna2Button button1;
        private Guna.UI2.WinForms.Guna2Button btnexit;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label questionlabel;
        private System.Windows.Forms.RadioButton option1;
        private System.Windows.Forms.RadioButton option2;
        private System.Windows.Forms.RadioButton option3;
        private System.Windows.Forms.RadioButton option4;
        private Guna.UI2.WinForms.Guna2Button btnnext;
        private Guna.UI2.WinForms.Guna2Button btnsubmit;
    }
}